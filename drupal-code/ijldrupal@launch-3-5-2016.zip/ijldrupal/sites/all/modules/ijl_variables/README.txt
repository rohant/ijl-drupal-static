IJL VARIABLES MODULE
---------------------------

SUMMARY:

  This is a small module written to provide extensions to Drupal's site variables.
  A prerequiste for this is the variable module found here:
  https://www.drupal.org/project/variable

INSTALLATION:

  1. Copy the module folder to your server.
  2. Enable the module via the modules page.

CONFIGURATION:

  * None required.
