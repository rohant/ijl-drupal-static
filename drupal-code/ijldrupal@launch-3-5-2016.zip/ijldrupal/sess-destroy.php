<?php
// Clear of sessions including active login
$params = session_get_cookie_params();
setcookie(session_name(), '', 0, $params['path'], $params['domain'], $params['secure'], isset($params['httponly']));
?>
<html>
<head>
<title>...</title>
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
</head>
<body>
	<pre>Session cleared...</pre>
	<?php phpinfo(); ?>
</body>
</html>
